#!/usr/bin/env ruby

require_relative 'reset_labels'
`git add _tag _category`
